package com.autotap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class AutoTapMod implements ClientModInitializer {

    public static boolean enabled   = false;
    public static boolean wTapMode  = true;
    public static int tapTimer = 0;

    private static final int WTAP_RELEASE_TICKS = 1;
    private static final int STAP_PRESS_TICKS   = 1;

    private static class_304 toggleKey;
    private static class_304 switchModeKey;

    @Override
    public void onInitializeClient() {
        class_304.class_11900 category = new class_304.class_11900(
                class_2960.method_60655("autotap", "custom_category")
        );

        toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.autotap.toggle",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_R,
                category
        ));

        switchModeKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.autotap.switchmode",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_G,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
    }

    private void onClientTick(class_310 client) {
        if (client.field_1724 == null) return;

        while (toggleKey.method_1436()) {
            String state = enabled ? "§aON" : "§cOFF";
            String mode  = wTapMode ? "§eW-Tap" : "§eS-Tap";
            client.field_1724.method_7353(class_2561.method_43470("§6[AutoTap] §r" + mode + " " + state), true);
        }

        while (switchModeKey.method_1436()) {
            tapTimer = 0;
            String mode = wTapMode ? "§eW-Tap" : "§eS-Tap";
            client.field_1724.method_7353(class_2561.method_43470("§6[AutoTap] §rMode switched to " + mode), true);
        }

        if (tapTimer > 0) tapTimer--;
    }

    public static void triggerTap() {
        tapTimer = wTapMode ? WTAP_RELEASE_TICKS : STAP_PRESS_TICKS;
    }
}
