package com.autotap.mixin;

import com.autotap.AutoTapMod;
import net.minecraft.class_241;
import net.minecraft.class_743;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_743.class)
public class KeyboardInputMixin {

    @Shadow protected class_241 movementVector;

    @Inject(method = "tick", at = @At("TAIL"))
    private void autotapOnTick(CallbackInfo ci) {
        if (AutoTapMod.wTapMode) {
            this.movementVector = new class_241(this.movementVector.field_1343, 0.0f);
        } else {
            this.movementVector = new class_241(this.movementVector.field_1343, -1.0f);
        }
    }
}
