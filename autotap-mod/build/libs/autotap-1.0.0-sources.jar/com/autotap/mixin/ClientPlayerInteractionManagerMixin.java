package com.autotap.mixin;

import com.autotap.AutoTapMod;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {

    /**
     * Fire the tap the moment the client sends an attack packet.
     * HEAD inject so the tap starts on the same tick as the hit.
     */
    @Inject(method = "attackEntity", at = @At("HEAD"))
    private void autotap$onAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
        AutoTapMod.triggerTap();
    }
}
